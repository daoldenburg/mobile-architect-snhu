package com.github.daoldenburg.snhu.mobilearchitecture.projectthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Debug;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.util.Base64;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    private InventoryDatabase mInventoryDb;
    private final String TAG = "LoginActivity.java";

    private EditText mUsernameField;
    private EditText mPasswordField;
    private TextView mErrorText;
    private boolean mUsernameEntered;
    private boolean mPasswordEntered;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // Initialize UI elements
        mUsernameField = findViewById(R.id.usernameField);
        mPasswordField = findViewById(R.id.passwordField);
        mErrorText = findViewById(R.id.errorPrompt);
        mInventoryDb = InventoryDatabase.getInstance(getApplicationContext());
        mErrorText.setText("");
        mErrorText.setVisibility(View.INVISIBLE);


    }

    public void onLoginClick(View view) {
        // Remove whitespace from username and password
        String username = mUsernameField.getText().toString().trim();
        String password = mPasswordField.getText().toString().trim();

        if (username.length() > 0 && password.length() > 0) {
            try {
                // Find matching user
                User user = mInventoryDb.userDao().getUser(username);
                // Hash submitted password
                String hashedPass = hashPassword(password);
                // Compare hashed password against stored password
                if (user.getPassword().equals(hashedPass)) {
                    // Password match -- start InventoryActivity, pass username as extra
                    Intent intent = new Intent(this, InventoryActivity.class);
                    intent.putExtra(InventoryActivity.EXTRA_USER_ID, username);
                    startActivity(intent);
                } else {
                    // Password mismatch
                    mErrorText.setText(getString(R.string.invalidUserOrPassword));
                    mErrorText.setVisibility(View.VISIBLE);
                }
            } catch(Exception e) {
                // Error in try block
                mErrorText.setText(getString(R.string.loginError));
                mErrorText.setVisibility(View.VISIBLE);
                Log.e(TAG, e.getMessage());
            }

        } else {
            // Either username or password is blank
            mErrorText.setText(getString(R.string.enterUsernameAndPasswordPrompt));
            mErrorText.setVisibility(View.VISIBLE);
        }
    }

    public void onCreateAccountClick(View view) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        String username = mUsernameField.getText().toString().trim();
        String password = mPasswordField.getText().toString().trim();
        // Enforce minimum lengths for username and password
        if (username.length() > 2 && password.length() > 7) {
            // Hash submitted password
            String hashedPass = hashPassword(password);
            // Create new user object from provided credentials
            User user = new User(username, hashedPass);
            try {
                // Try to insert user into database
                mInventoryDb.userDao().insertUser(user);
            } catch (Exception e) {
                // Insert failed, likely due to duplicate username
                mErrorText.setText(getString(R.string.usernameAlreadyExists, username));
                mErrorText.setVisibility(View.VISIBLE);
            }

        } else {
            // Username or password do not meet minimum length
            mErrorText.setText(getString(R.string.enterUsernameAndPasswordPrompt));
            mErrorText.setVisibility(View.VISIBLE);
        }
    }

    // This method uses the hashing algorithm SHA-256 to hash the submitted password.
    // The hashed value will be stored in the database instead of passwords in plain text.
    private String hashPassword(String password) throws NoSuchAlgorithmException,
            UnsupportedEncodingException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        byte[] hashInput = password.getBytes("UTF-8");
        byte[] hashOutput = messageDigest.digest(hashInput);
        String hashedPass = Base64.encodeToString(hashOutput, Base64.DEFAULT).toLowerCase();
        return hashedPass;
    }
}