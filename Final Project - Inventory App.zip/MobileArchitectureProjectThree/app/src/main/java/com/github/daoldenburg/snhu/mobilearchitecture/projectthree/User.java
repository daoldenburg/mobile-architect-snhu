package com.github.daoldenburg.snhu.mobilearchitecture.projectthree;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;



@Entity(tableName = "users")
public class User {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "username")
    private String mUsername = "";
    
    @ColumnInfo(name = "password")
    private String mPassword = "";

    @ColumnInfo(name = "updated")
    private long mUpdateTime;

    public User() {
        mUpdateTime = System.currentTimeMillis();
    }

    @Ignore
    public User(String username, String password) {
        mUsername = username;
        mPassword = password;
        mUpdateTime = System.currentTimeMillis();
    }

    public String getUsername() {
        return mUsername;
    }

    public void setUsername(String username) {
        mUsername = username;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String password) {
        mPassword = password;
    }

    public long getUpdateTime() {
        return mUpdateTime;
    }

    public void setUpdateTime(long updateTime) {
        mUpdateTime = updateTime;
    }
}