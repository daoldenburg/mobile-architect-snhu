package com.github.daoldenburg.snhu.mobilearchitecture.projectthree;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ItemDetailActivity extends AppCompatActivity {

    public static final String EXTRA_ITEM_ID = "com.github.daoldenburg.snhu.mobilearchitecture.projectthree.EXTRA_ITEM";
    public static final String EXTRA_USERNAME = "com.github.daoldenburg.snhu.mobilearchitecture.projectthree.EXTRA_USERNAME";
    private static final String SMS_NUMBER = "+1-555-521-5554";
    private EditText mItemNameTextField;
    private EditText mItemQuantityField;
    private EditText mItemDescriptionField;
    private Button mPlusButton;
    private Button mMinusButton;
    private InventoryDatabase mInventoryDb;
    private InventoryItem mCurrentItem;
    private long mItemId;
    private String mUsername;
    private boolean mIsNewItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        // Initialize UI elements
        mItemNameTextField = findViewById(R.id.itemNameField);
        mItemQuantityField = findViewById(R.id.itemQuantityField);
        mItemDescriptionField = findViewById(R.id.itemDescriptionField);
        mPlusButton = findViewById(R.id.plusButton);
        mMinusButton = findViewById(R.id.minusButton);

        // Initialize database
        mInventoryDb = InventoryDatabase.getInstance(getApplicationContext());

        // Get activity intent to determine if new or existing item
        Intent intent = getIntent();
        mUsername = intent.getStringExtra(EXTRA_USERNAME);
        mItemId = intent.getLongExtra(EXTRA_ITEM_ID, -1);
        if (mItemId >= 0) {
            // Existing item; update title and get reference to item from database
            setTitle(R.string.editItemTitle);
            mCurrentItem = mInventoryDb.itemDao().getInventoryItem(mItemId);
        }
        else {
            // New item; update title and create new item
            setTitle(R.string.newItemTitle);
            mCurrentItem = new InventoryItem("", 0, "", intent.getStringExtra(EXTRA_USERNAME));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Update text of UI elements
        mItemNameTextField.setText(mCurrentItem.getName());
        mItemQuantityField.setText(String.valueOf(mCurrentItem.getQuantity()));
        mItemDescriptionField.setText(mCurrentItem.getDescription());
    }

    public void onSaveClick(View view) {
        // Entered values from UI
        String enteredName = mItemNameTextField.getText().toString().trim();
        long enteredQuantity = Long.parseLong(mItemQuantityField.getText().toString().trim());
        String enteredDescription = mItemDescriptionField.getText().toString().trim();

        if (mItemId == -1) {
            // New item
            // Insert new item into database
            InventoryItem newItem = new InventoryItem(
                    enteredName,
                    Long.parseLong(mItemQuantityField.getText().toString().trim()),
                    mItemDescriptionField.getText().toString().trim(),
                    mUsername);
            mInventoryDb.itemDao().insertInventoryItem(newItem);
        } else {
            // Existing item
            // Check if quantity was set to 0
            if (enteredQuantity == 0 && mCurrentItem.getQuantity() > 0) {
                // Send SMS out-of-stock alert
                sendSMS(SMS_NUMBER, getString(R.string.outOfStock, enteredName));
            }
            // Update existing item in database
            mCurrentItem.setName(enteredName);
            mCurrentItem.setQuantity(enteredQuantity);
            mCurrentItem.setDescription(enteredDescription);
            mInventoryDb.itemDao().updateInventoryItem(mCurrentItem);
        }
        finish();
    }

    public void onDeleteClick(View view) {
        // Send SMS deleted-item alert
        sendSMS(SMS_NUMBER, getString(R.string.itemDeleted, mCurrentItem.getName()));
        mInventoryDb.itemDao().deleteInventoryItem(mCurrentItem);
        finish();
    }

    public void onPlusClick(View view) {
        Long currentQuantity = Long.parseLong(mItemQuantityField.getText().toString().trim());
        mItemQuantityField.setText(Long.toString(currentQuantity + 1));
    }

    public void onMinusClick(View view) {
        Long currentQuantity = Long.parseLong(mItemQuantityField.getText().toString().trim());
        mItemQuantityField.setText(Long.toString(currentQuantity - 1));
    }
    public void sendSMS(String mobileNumber, String message) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
        {
            try
            {
                SmsManager smsMgr = SmsManager.getDefault();
                smsMgr.sendTextMessage(mobileNumber, null, message, null, null);
                Toast.makeText(getApplicationContext(), getString(R.string.message_sent),
                        Toast.LENGTH_LONG).show();
            }
            catch (Exception ErrVar)
            {
                Toast.makeText(getApplicationContext(),ErrVar.getMessage().toString(),
                        Toast.LENGTH_LONG).show();
                ErrVar.printStackTrace();
            }
        }
        else
        {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            {
                requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 10);
            }
        }
    }
}