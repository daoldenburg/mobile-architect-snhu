package com.github.daoldenburg.snhu.mobilearchitecture.projectthree;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    public static final String EXTRA_USER_ID = "com.github.daoldenburg.snhu.mobilearchitecture.projectthree.EXTRA_USER_ID";

    private InventoryDatabase mInventoryDb;
    private List<InventoryItem> inventoryItems;
    private RecyclerView mRecyclerView;
    private InventoryItemAdapter mItemAdapter;
    private List<InventoryItem> mItems;
    private String mUsername;

    // Members for InventoryHolder
    private InventoryItem mSelectedItem;
    private int mSelectedItemPosition = RecyclerView.NO_POSITION;
    private ActionMode mActionMode = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        Intent intent = getIntent();
        // Get username and database
        mUsername = intent.getStringExtra(EXTRA_USER_ID);
        mInventoryDb = InventoryDatabase.getInstance(getApplicationContext());

        // Initialize RecyclerView and LayoutManager
        mRecyclerView = findViewById(R.id.itemRecyclerView);
        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getApplicationContext(), 1);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        // Shows the available items
        mItemAdapter = new InventoryItemAdapter(loadItems(mUsername));
        mRecyclerView.setAdapter(mItemAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload item adapter in case something changed
        mItemAdapter = new InventoryItemAdapter(loadItems(mUsername));
        mRecyclerView.setAdapter(mItemAdapter);
    }

    private List<InventoryItem> loadItems(String user) {
        return mInventoryDb.itemDao().getInventoryItemsNewerFirst(user);
    }

    private class InventoryItemHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private InventoryItem mInventoryItem;
        private TextView mNameTextView;
        private TextView mQuantityField;

        public InventoryItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            itemView.setOnClickListener(this);
            mNameTextView = itemView.findViewById(R.id.itemNameTextView);
            mQuantityField = itemView.findViewById(R.id.itemQuantityField);
        }

        public void bind(InventoryItem inventoryItem, int position) {
            mInventoryItem = inventoryItem;
            mNameTextView.setText(mInventoryItem.getName());
            mQuantityField.setText(Long.toString(mInventoryItem.getQuantity()));

        }

        @Override
        public void onClick(View view) {
            // Start ItemDetailActivity, indicating what inventoryItem was clicked
            Intent intent = new Intent(InventoryActivity.this, ItemDetailActivity.class);
            intent.putExtra(ItemDetailActivity.EXTRA_ITEM_ID, mInventoryItem.getId());
            intent.putExtra(ItemDetailActivity.EXTRA_USERNAME, mUsername);
            startActivity(intent);
        }
    }

    public void addItemClick(View view) {
        // Load ItemDetailActivity for a new item by not providing EXTRA_ITEM_ID
        Intent intent = new Intent(InventoryActivity.this, ItemDetailActivity.class);
        intent.putExtra(ItemDetailActivity.EXTRA_USERNAME, mUsername);
        startActivity(intent);
    }

    private class InventoryItemAdapter extends RecyclerView.Adapter<InventoryItemHolder> {

        private List<InventoryItem> mInventoryItemList;

        public InventoryItemAdapter(List<InventoryItem> inventoryItems) {
            mInventoryItemList = inventoryItems;
        }

        @Override
        public InventoryItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new InventoryItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(InventoryItemHolder holder, int position) {
            holder.bind(mInventoryItemList.get(position), position);
        }

        @Override
        public int getItemCount() {
            return mInventoryItemList.size();
        }

    }
}