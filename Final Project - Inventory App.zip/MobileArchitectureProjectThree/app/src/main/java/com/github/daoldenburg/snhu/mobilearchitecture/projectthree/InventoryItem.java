package com.github.daoldenburg.snhu.mobilearchitecture.projectthree;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import static androidx.room.ForeignKey.CASCADE;

@Entity(tableName = "inventoryItems",
        foreignKeys = @ForeignKey(onDelete = CASCADE,
                entity = User.class,
                parentColumns = "username",
                childColumns = "user"))
public class InventoryItem {


    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long mId;

    @ColumnInfo(name = "name")
    private String mName = "";

    @ColumnInfo(name = "quantity")
    private long mQuantity;

    @ColumnInfo(name = "description")
    private String mDescription;

    @ColumnInfo(name = "user")
    private String mUser;

    @ColumnInfo(name = "updated")
    private long mUpdateTime;

    public InventoryItem() { mUpdateTime = System.currentTimeMillis(); }

    @Ignore
    public InventoryItem(String name, long quantity, String description, String user) {
        mName = name;
        mQuantity = quantity;
        mDescription = description;
        mUser = user;
        mUpdateTime = System.currentTimeMillis();
    }

    @Ignore
    public InventoryItem(String name, int quantity) {
        mName = name;
        mQuantity = quantity;
        mDescription = "";
        mUpdateTime = System.currentTimeMillis();
    }

    public String getName() {
        return mName;
    }

    public void setId(long id) {
        mId = id;
    }

    public long getId() {
        return mId;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        mDescription = description;
    }

    public String getUser() {
        return mUser;
    }

    public void setUser(String user) {
        mUser = user;
    }

    public long getQuantity() { return mQuantity; }

    public void setQuantity(long quantity) { mQuantity = quantity; }

    public long getUpdateTime() { return mUpdateTime; }

    public void setUpdateTime(long updateTime) { mUpdateTime = updateTime; }
}