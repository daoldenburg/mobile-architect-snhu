package com.github.daoldenburg.snhu.mobilearchitecture.projectthree;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface UserDao {

    @Query("SELECT * FROM users ORDER BY username")
    public List<User> getUsers();

    @Query("SELECT * FROM users WHERE username = :username")
    public User getUser(String username);

    @Query("SELECT * FROM users ORDER BY updated DESC")
    public List<User> getUsersNewerFirst();

    @Query("SELECT * FROM users ORDER BY updated ASC")
    public List<User> getUsersOlderFirst();

    @Insert
    public void insertUser(User user);

    @Update
    public void updateUser(User user);

    @Delete
    public void deleteUser(User user);
}